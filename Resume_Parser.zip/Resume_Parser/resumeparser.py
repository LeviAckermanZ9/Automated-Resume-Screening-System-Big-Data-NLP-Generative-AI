import google.generativeai as genai
import yaml
import pdfplumber  

CONFIG_PATH = "config.yaml"

with open(CONFIG_PATH, "r") as file:
    data = yaml.safe_load(file)
    api_key = data.get('GEMINI_API_KEY')

if not api_key:
    raise ValueError("GEMINI_API_KEY not found in config.yaml")

genai.configure(api_key=api_key)

def extract_text_from_pdf(file_path):
    """Extract text from a PDF file."""
    with pdfplumber.open(file_path) as pdf:
        text = "\n".join([page.extract_text() for page in pdf.pages if page.extract_text()])
    return text

def ats_extractor(file_path):
    """Parse resume PDF using Gemini AI."""
    resume_text = extract_text_from_pdf(file_path)

    if not resume_text:
        return {"error": "Could not extract text from PDF"}

    prompt = """
    You are an AI that extracts structured resume information. Extract:
    - Name
    - Email
    - Phone
    - LinkedIn
    - GitHub
    - Skills
    - Experience
    Return the result in JSON format.
    """

    model = genai.GenerativeModel("gemini-pro")
    response = model.generate_content([prompt, resume_text])

    return response.text  
